package com.example.projetresto.modele.metier;

public class critiquer {
//    protected int idR;
//    protected int idU;
//    protected int note;
//    protected String commentaire;
//
//
//    public critiquer(int idR, int idU, int note, String commentaire) {
//        this.idR = idR;
//        this.idU = idU;
//        this.note = note;
//        this.commentaire = commentaire;
//    }
//
//    public int getIdR() {
//        return idR;
//    }
//
//    public void setIdR(int idR) {
//        this.idR = idR;
//    }
//
//    public int getIdU() {
//        return idU;
//    }
//
//    public void setIdU(int idU) {
//        this.idU = idU;
//    }
//
//    public int getNote() {
//        return note;
//    }
//
//    public void setNote(int note) {
//        this.note = note;
//    }
//
//    public String getCommentaire() {
//        return commentaire;
//    }
//
//    public void setCommentaire(String commentaire) {
//        this.commentaire = commentaire;
//    }







}
