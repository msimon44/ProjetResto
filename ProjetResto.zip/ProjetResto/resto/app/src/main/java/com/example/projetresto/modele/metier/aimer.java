package com.example.projetresto.modele.metier;

public class aimer {

//        protected int idR;
//        protected int idU;
//
//        public aimer(int idR, int idU) {
//            this.idR = idR;
//            this.idU = idU;
//        }
//
//
//
//        public int getIdR() {
//            return idR;
//        }
//
//        public void setIdR(int idR) {
//            this.idR = idR;
//        }
//
//        public int getIdU() {
//            return idU;
//        }
//
//        public void setIdU(int idU) {
//            this.idU = idU;
//        }



















    }



















